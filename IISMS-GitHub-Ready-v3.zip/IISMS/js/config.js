const SUPABASE_URL='https://osnlrkadjcvpxscyklbn.supabase.co';
const SUPABASE_PUBLISHABLE_KEY='sb_publishable_0C4hv49UkXMu0Nwz7anAJg_KPc9HPYB';
const supabaseClient=window.supabase.createClient(SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY);
