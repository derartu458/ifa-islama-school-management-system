# IISMS — Ifa Islama School Management System

GitHub/Vercel-ready PWA milestone connected to Supabase.

Includes Home, About, Contact, 4 registration types, protected Secret login, Admin login/dashboard, application accept/decline with class/section assignment, records, payments view, announcements, language selector and PWA service worker.

Supabase URL: https://osnlrkadjcvpxscyklbn.supabase.co

The browser uses the Supabase publishable key in `js/config.js`. Never put a service-role/secret key in frontend code.

Next production modules: full attendance UI, marks/semester/annual roster, payment screenshot Storage upload, richer role permissions and automated result calculations.
